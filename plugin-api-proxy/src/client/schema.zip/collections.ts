
// 利用制限の選択肢の配列
export const enumRequestLimit = [
    { label: 'なし', value: 'none' },
    { label: '日次', value: 'daily' },
    { label: '週次', value: 'weekly' },
    { label: '月次', value: 'monthly' },
    { label: '年次', value: 'yearly' },
];

// APIのコレクション
//  @ref ../server/collection/api_proxy_apis
export const apiProxyApisCollection = {
  name: 'api_proxy_apis',
  filterTargetKey: 'id',
  fields: [
    {
      type: 'string',
      name: 'name',
      interface: 'input',
      uiSchema: {
        title: '名前',
        required: true,
        'x-component': 'Input',
      },
    },
    {
      type: 'string',
      name: 'url',
      interface: 'input',
      uiSchema: {
        title: 'URL',
        required: true,
        'x-component': 'Input.URL',
      },
    },
    {
      type: 'text',
      name: 'description',
      interface: 'textarea',
      uiSchema: {
        title: '説明',
        'x-component': 'Input.TextArea',
      },
    },
    {
      type: 'string',
      name: 'limit',
      interface: 'select',
      uiSchema: {
        title: '利用制限',
        enum: enumRequestLimit, // none, daily, weekly, monthly, yearly 
        default: 'none',
        'x-component': 'Select',
      },
    },
    {
      type: 'integer',
      name: 'maxRequests',
      interface: 'number',
      uiSchema: {
        title: '最大リクエスト数',
        'x-component': 'Input',
        default: 0,
      },
    },
    {
      type: 'integer',
      name: 'limitStartWeekday',
      interface: 'select',
      uiSchema: {
        title: '週次制限開始曜日',
        enum: [
          { label: '日', value: 0 },
          { label: '月', value: 1 },
          { label: '火', value: 2 },
          { label: '水', value: 3 },
          { label: '木', value: 4 },
          { label: '金', value: 5 },
          { label: '土', value: 6 },
        ],
        default: 0,
        'x-component': 'Select',
      },
    },
    {
      type: 'integer',
      name: 'limitStartMonth',
      interface: 'number',
      uiSchema: {
        title: '年次制限開始月 (1-12)',
        'x-component': 'Input',
        minimum: 1,
        maximum: 12,
      },
    },
    {
      type: 'integer',
      name: 'limitStartDay',
      interface: 'number',
      uiSchema: {
        title: '月次/年次制限開始日 (1-31)',
        'x-component': 'Input',
        minimum: 1,
        maximum: 31,
      },
    },
    {
      type: 'time',
      name: 'limitStartTime',
      interface: 'time',
      uiSchema: {
        title: '制限開始時刻',
        'x-component': 'TimePicker',
      },
    },
    {
      type: 'integer',
      name: 'currentAccessCount',
      interface: 'number',
      uiSchema: {
        title: '現在の利用回数',
        'x-component': 'Input',
        default: 0,
        readOnly: true,
      },
    },
    {
      type: 'date',
      name: 'lastAccessAt',
      interface: 'datetime',
      uiSchema: {
        title: '最終アクセス時刻',
        'x-component': 'DatePicker',
        'x-component-props': {
          showTime: true,
        },
        readOnly: true,
      },
    },
  ],
};
