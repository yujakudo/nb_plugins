// client/index.tsx
import { Plugin } from '@nocobase/client';
import { name } from '../../package.json';
import React from 'react';
import { ExtendCollectionsProvider, SchemaComponent } from '@nocobase/client';
import { apiProxyApisCollection } from './collections';
import { useSubmitActionProps, useEditFormProps, useDeleteActionProps } from './hooks';
import { settingPageSchema } from './schema';

class ApiProxyPluginClient extends Plugin {
  async load() {
    // 設定ページの登録
    this.app.pluginSettingsManager.add(name, {
      title: 'API Proxy',
      icon: 'Partition',
      Component: () => {
        return (
          <ExtendCollectionsProvider collections={[apiProxyApisCollection]}>
            <SchemaComponent schema={settingPageSchema} scope={{ useSubmitActionProps, useEditFormProps, useDeleteActionProps }} />
          </ExtendCollectionsProvider>
        );
      },
    });
  }
}

export default ApiProxyPluginClient;
